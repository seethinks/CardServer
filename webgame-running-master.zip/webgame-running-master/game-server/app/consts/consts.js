module.exports = {
	RedisKey: {
    USER_LIST: 'POMELO:user_list',  //在线用户名单
    USER_RANK: 'POMELO:user_rank'
  }
}