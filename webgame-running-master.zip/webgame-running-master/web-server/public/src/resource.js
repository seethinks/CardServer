var s_HelloWorld = "res/HelloWorld.png";
var s_CloseNormal = "res/CloseNormal.png";
var s_CloseSelected = "res/CloseSelected.png";
var s_Maphd = "res/tmw_desert_spacing-hd.png";
var s_Player =  "res/player.jpg";
var s_playNormal = "res/btn-play-normal.png";
var s_playSelect = "res/btn-play-selected.png";

var g_ressources = [
    //image
    {src:s_HelloWorld},
    {src:s_CloseNormal},
    {src:s_CloseSelected},
    {src:s_Maphd},
    {src:s_Player},
    {src:s_playNormal},
    {src:s_playSelect},

    //plist

    //fnt

    //tmx
    {src:"res/running.tmx"},
    //bgm

    //effect
];